$("ul").on("click","li",function(){
    //  alert("clicked li");
     $(this).toggleClass("completed");
})

$("ul").on("click","span",function(event){
    // alert("clicked span");
    $(this).parent().fadeOut(function(){
        $(this).remove();
    });
    event.stopPropagation();
});

$("input").keypress(function(event){
    if(event.which == 13){
        var newLi=$(this).val();
        $("ul").append("<li><span><i class=\"far fa-trash-alt\"></i></span> "+newLi+"</li>");
        $(this).val("");
    }
})
$(".fa-plus").on("click",function(){
     $("input").toggleClass("displayInput");
})